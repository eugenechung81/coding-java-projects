<a target="_blank" href="https://chrome.google.com/webstore/detail/eahldfpkmibbaajaoeifhjeehfgdagdm">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Printest

This application demonstrates printing. It supports the creation of any number
of windows, each of which can be printed by a button on the window, and the most
recently accessed window can be printed from a control window. A timer based
animation can be displayed on the control window to demonstrates how timers are
suspended while printing.

## Screenshot
![screenshot](https://raw.github.com/GoogleChrome/chrome-app-samples/master/printing/assets/screenshot_1280_800.png)

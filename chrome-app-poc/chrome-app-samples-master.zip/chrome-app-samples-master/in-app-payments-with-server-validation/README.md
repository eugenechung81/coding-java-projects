# In App Payments with server-side validation

This is a simple test/sample app showing how to use the in-app payments API in a Chrome App and validating the purchase in an AppEngine server application.

     
## Screenshot
![screenshot](https://raw.github.com/GoogleChrome/chrome-app-samples/master/in-app-payments-with-server-validation/chromeapp/assets/screenshot_1280_800.png)


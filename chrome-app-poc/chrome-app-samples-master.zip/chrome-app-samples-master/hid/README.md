<a target="_blank" href="https://chrome.google.com/webstore/detail/ohndmecdhlgohpibepbboddcoecomnpc">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


chrome.hid API Sample
=====================

This sample demonstrates usage of the chrome.hid API.
Note that in order to use this sample, you will need
to update the `usbDevices` list in `manifest.json`
with one or more VID/PID pairs corresponding to your
hardware of choice.


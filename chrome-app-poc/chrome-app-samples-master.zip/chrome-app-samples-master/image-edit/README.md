<a target="_blank" href="https://chrome.google.com/webstore/detail/foibnkkcggahkmckladbmgkajodpcjfh">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Crop Tool - Image Edit

A tool to crop images.

Open files, or drag and drop them. Perform a simple crop and save the result.

Works offline.

## Try it: [Crop Tool - Image Edit](https://chrome.google.com/webstore/detail/crop-tool-image-edit/foibnkkcggahkmckladbmgkajodpcjfh)

## Screenshot
![screenshot](https://raw.github.com/GoogleChrome/chrome-app-samples/master/image-edit/assets/screenshot_1280_800.png)

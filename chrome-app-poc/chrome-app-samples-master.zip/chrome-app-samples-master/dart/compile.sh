#!/bin/bash

pub get
dart2js -odart/clock.dart.js dart/clock.dart
